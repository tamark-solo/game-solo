import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,mkdtemp} from 'node:fs/promises';
import {resolve} from 'node:path';
import {chromium} from 'playwright';
import {startService} from '../support/services.mjs';
const root=resolve('docs/design/characters/van-hai-monster-animation-v1'),out=resolve('artifacts/monster-cluster');await mkdir(out,{recursive:true});
const fixture=await mkdtemp(out+'/fixture-'),config=fixture+'/vite.mjs',origin='http://127.0.0.1:5228';
await writeFile(config,`export default {root:${JSON.stringify(resolve('client'))},publicDir:${JSON.stringify(resolve('client/public'))},server:{host:'127.0.0.1',strictPort:true,fs:{allow:[${JSON.stringify(resolve('.'))}]}}};`);
const vite=await startService(['node_modules/vite/bin/vite.js','--config',config,'--port','5228'],origin);let browser;const errors=[],api=[],results=[];
try{
 browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});const context=await browser.newContext({viewport:{width:1440,height:1050}}),page=await context.newPage();
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/\/api\/|\/matchmake\//.test(r.url()))api.push(r.url());});
 await page.goto(origin+'/@fs/'+root.replaceAll('\\','/')+'/cluster.html');await page.waitForSelector('body[data-ready=true]');await page.locator('#play').click();await page.locator('#loop').uncheck();
 const storage=await page.evaluate(()=>[JSON.stringify({...localStorage}),JSON.stringify({...sessionStorage})]);
 async function seek(age){
  // A previous render can already have this age after a fact or toggle changes.
  // Publish a different age first so the target wait observes a fresh render.
  for(const nextAge of [age===0?1:0,age]){
   await page.locator('#age').evaluate((e,v)=>{e.value=String(v);e.dispatchEvent(new Event('input'));},nextAge);
   await page.waitForFunction(v=>Number(document.querySelector('#cluster-stage').dataset.sceneTime)===v,nextAge);
  }
 }
 async function stats(){return JSON.parse(await page.locator('#cluster-stage').getAttribute('data-stats'));}
 for(const preset of ['same','mixed','escort'])for(const count of [3,6,9,12,18]){
  await page.locator('#preset').selectOption(preset);await page.locator('#count').selectOption(String(count));await page.locator('#timing').selectOption('salvo');await page.locator('#spacing').selectOption('110');await seek(800);
  let s=await stats();assert.equal(s.actors,count);assert.ok(s.effects>0);assert.ok(s.cache.decodedBytes<=s.cache.budgetBytes);
  await page.locator('#clarity').selectOption('managed');await page.waitForFunction(()=>document.querySelector('#cluster-stage').dataset.clarity==='managed');const managed=await stats();assert.ok(managed.fxCoverage<=s.fxCoverage);
  results.push({preset,count,time:800,full:{fxCoverage:s.fxCoverage,bodyCoverage:s.bodyCoverage,effects:s.effects},managed:{fxCoverage:managed.fxCoverage,bodyCoverage:managed.bodyCoverage,effects:managed.effects}});
  await page.locator('#clarity').selectOption('full');await page.waitForFunction(()=>document.querySelector('#cluster-stage').dataset.clarity==='full');
 }
 await page.locator('#preset').selectOption('same');await page.locator('#count').selectOption('6');await page.locator('#timing').selectOption('stagger');
 for(const actor of ['cloud-wolf','talisman-sprout','jade-scute','ink-bat','cracked-puppet','spirit-fungus','dark-talisman-rogue','quiet-wisp','wolf-caller','jade-guard','black-silk-adept']){await page.locator('#actor').selectOption(actor);await seek(900);assert.equal((await stats()).actors,6);assert.equal(await page.locator('body').getAttribute('data-error'),null);if(actor==='cloud-wolf')await page.locator('#cluster-stage').screenshot({path:out+'/wolves-6-native.png'});}
 await page.locator('#preset').selectOption('escort');for(const actor of ['wolf-caller','jade-guard','black-silk-adept']){await page.locator('#actor').selectOption(actor);await seek(900);assert.equal((await stats()).elites,1);}
 await page.locator('#preset').selectOption('escort');await page.locator('#actor').selectOption('jade-guard');await page.locator('#count').selectOption('6');await page.locator('#timing').selectOption('stagger');await seek(900);await page.locator('#cluster-stage').screenshot({path:out+'/escort-6-native.png'});
 await page.locator('#preset').selectOption('mixed');await page.locator('#count').selectOption('18');await page.locator('#spacing').selectOption('64');await page.locator('#timing').selectOption('salvo');await seek(800);await page.screenshot({path:out+'/crowd-full-desktop.png',fullPage:true});await page.locator('#cluster-stage').screenshot({path:out+'/crowd-full-native.png'});
 const worst=await stats();await page.locator('#clarity').selectOption('managed');await page.waitForFunction(()=>document.querySelector('#cluster-stage').dataset.clarity==='managed');const readable=await stats();assert.ok(readable.fxCoverage<worst.fxCoverage);await page.screenshot({path:out+'/crowd-managed-desktop.png',fullPage:true});await page.locator('#cluster-stage').screenshot({path:out+'/crowd-managed-native.png'});
 await page.locator('#fact').selectOption('miss');await seek(800);assert.ok((await stats()).effects<worst.effects);
 await page.locator('#fact').selectOption('cancel');await seek(800);assert.equal((await stats()).effects,0);
 await page.locator('#fact').selectOption('hit');await page.locator('#fx').uncheck();await seek(800);assert.equal((await stats()).effects,0);assert.equal((await stats()).warnings,0);await page.locator('#fx').check();
 await page.locator('#timing').selectOption('stagger');await seek(300);assert.ok((await stats()).warnings>0);await page.locator('#warnings').uncheck();await seek(300);assert.equal((await stats()).warnings,0);await page.locator('#warnings').check();
 await page.locator('#aim').selectOption('parallel');for(const d of ['north','east','southwest']){await page.locator('#direction').selectOption(d);await seek(800);assert.equal((await stats()).actors,18);}await page.locator('#aim').selectOption('converge');
 await page.locator('#scene').selectOption('light');await page.locator('#zoom').selectOption('2');await seek(800);await page.locator('#cluster-stage').screenshot({path:out+'/crowd-light-2x.png'});await page.locator('#scene').selectOption('dark');await seek(800);await page.locator('#cluster-stage').screenshot({path:out+'/crowd-dark-2x.png'});await page.locator('#scene').selectOption('map');await page.locator('#zoom').selectOption('1');
 await page.locator('#loop').check();await page.locator('#play').click();await page.waitForTimeout(900);assert.equal(await page.locator('body').getAttribute('data-error'),null);await context.setOffline(true);await page.waitForTimeout(80);const paused=await page.locator('#cluster-stage').getAttribute('data-scene-time');await page.waitForTimeout(180);assert.equal(await page.locator('#cluster-stage').getAttribute('data-scene-time'),paused);await context.setOffline(false);await page.waitForTimeout(100);await page.locator('#play').click();
 await page.emulateMedia({reducedMotion:'reduce'});const reduced=await page.locator('#cluster-stage').getAttribute('data-scene-time');await page.waitForTimeout(180);assert.equal(await page.locator('#cluster-stage').getAttribute('data-scene-time'),reduced);await page.emulateMedia({reducedMotion:'no-preference'});
 const cache=JSON.parse(await page.locator('body').getAttribute('data-cache'));assert.ok(cache.decodedBytes<=cache.budgetBytes&&cache.evictions>0);
 for(const width of [768,390]){await page.setViewportSize({width,height:900});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);assert.ok(await page.locator('.stage-scroll').evaluate(e=>e.scrollWidth>e.clientWidth));}await page.screenshot({path:out+'/cluster-mobile.png',fullPage:true});
 assert.deepEqual(await page.evaluate(()=>[JSON.stringify({...localStorage}),JSON.stringify({...sessionStorage})]),storage);assert.deepEqual(errors,[]);assert.deepEqual(api,[]);
 const report={passed:true,date:'2026-10-13',scenarios:results,worst:{full:worst,managed:readable},cache,errors,api,checks:['same/mixed/escort x3/6/9/12/18','all11species and3elite-family selections','own clock/body/pivot and world-foot depth','salvo/stagger and parallel/convergent directions','same source art in full/managed; measured pixel coverage improves','miss/cancel/FX/warning toggles','1x/2x map/light/dark screenshots','18 actors playing without detached bitmaps','16MiB canonical-frame cache with eviction','offline/reduced-motion pause','390/768 without page overflow','no API/storage/owner map/DB writes'],runtimeImplemented:false,crowdArtApproved:false};await writeFile(out+'/verification.json',JSON.stringify(report,null,2)+'\n');console.log({...report,scenarios:results.length});
}finally{await browser?.close();vite.stop();}
