import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';

const require=createRequire(import.meta.url);
let sharp;
try{sharp=require('sharp');}catch{sharp=require(resolve(process.env.USERPROFILE??process.env.HOME,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp'));}
const folder=resolve('docs/design/characters/van-hai-player-chibi-v1');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const source=await readFile(resolve(folder,'standing-source.png'));
const meta=await sharp(source).metadata();
const {data,info}=await sharp(source).ensureAlpha().raw().toBuffer({resolveWithObject:true});
let left=info.width,top=info.height,right=-1,bottom=-1,transparent=0,opaque=0;
for(let y=0;y<info.height;y++)for(let x=0;x<info.width;x++){
 const a=data[(y*info.width+x)*4+3];
 if(a===0)transparent++;if(a>=240)opaque++;
 if(a>8){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);}
}
if(!meta.hasAlpha||transparent<info.width*info.height*.1||opaque<1000||right<left)throw new Error('Standing source requires genuine transparent alpha and an opaque figure');
// Only mechanical crop/resample; keep the original source and all pixels inside the crop.
left=Math.max(0,left-4);top=Math.max(0,top-4);right=Math.min(info.width-1,right+4);bottom=Math.min(info.height-1,bottom+4);
const crop={left,top,width:right-left+1,height:bottom-top+1};
const web=await sharp(source).extract(crop).resize({height:1024,withoutEnlargement:true}).webp({quality:94,alphaQuality:100}).toBuffer();
const reduced=await sharp(source).extract(crop).resize({width:64,height:80,fit:'inside',kernel:'lanczos3'}).png().toBuffer();
const size=await sharp(reduced).metadata(),placement={left:Math.round(32-size.width/2),top:88-size.height};
const study=await sharp({create:{width:64,height:96,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite([{input:reduced,...placement}]).png().toBuffer();
await writeFile(resolve(folder,'standing.webp'),web);await writeFile(resolve(folder,'standing-study.png'),study);
const reference='docs/design/characters/wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png';
const baseline=await readFile(reference);await copyFile(reference,resolve(folder,'baseline.png'));
const concept='docs/design/characters/van-hai-player-v2/concept-source.png';
const manifest={date:'2026-10-11',id:'VHD-PLAYER-CHIBI-01',status:'pending-owner-art-review',ownerApproved:false,artApproved:false,tool:'built-in image_gen',prompt:'standing.prompt.txt',directionDecision:{evidence:'Tôi đồng ý. hãy thiết kế theo đề xuất của bạn và đặt cạnh so sánh với chibi hiện hành',scope:'Create a restrained chibi from concept 02 and compare on the map; approval of direction, not the generated result.'},source:{file:'standing-source.png',size:[meta.width,meta.height],sha256:hash(source),alpha:true,crop},inputs:[{path:concept,sha256:hash(await readFile(concept)),role:'Accepted concept 02 identity, hair and middle gray-jade cloth costume'},{path:reference,sha256:hash(baseline),role:'Elevated south camera, native frame and readability reference only; not copied identity'}],contract:{framePx:[64,96],anchorPx:[32,88],targetBodyPx:80,resamplePx:[size.width,size.height],placementPx:placement,defaultCameraZoom:1,worldPx:[3072,2048],productionNative:false,runtimeIntegrated:false,softAlpha:true,paletteLocked:false},assets:[{id:'standing',file:'standing.webp',sha256:hash(web),bytes:web.length,role:'Source preview; simplified chibi from concept 02'},{id:'standing-study',file:'standing-study.png',size:[64,96],anchorPx:[32,88],sha256:hash(study),bytes:study.length,role:'One idle south scale study; not a production atlas'},{id:'baseline',file:'baseline.png',size:[64,96],anchorPx:[32,88],sha256:hash(baseline),bytes:baseline.length,role:'Current chibi, byte-identical comparison'}]};
// Repackaging identical art preserves its decision; changed art always needs a fresh review.
try{const previous=JSON.parse(await readFile(resolve(folder,'assets.json'),'utf8'));if(previous.source?.sha256===manifest.source.sha256){for(const key of ['status','ownerApproved','artApproved','approval'])if(previous[key]!==undefined)manifest[key]=previous[key];}}catch(error){if(error.code!=='ENOENT')throw error;}
await writeFile(resolve(folder,'assets.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({source:manifest.source.size,alpha:true,crop,body:manifest.contract.resamplePx,frame:[64,96],anchor:[32,88],ownerApproved:manifest.ownerApproved}));
