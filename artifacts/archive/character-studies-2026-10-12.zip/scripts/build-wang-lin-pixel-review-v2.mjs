import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);let sharp;
try{sharp=require('sharp');}catch{sharp=require(resolve(process.env.USERPROFILE??process.env.HOME,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp'));}
const folder=resolve('docs/design/characters/wang-lin-pixel-review-v2'),hash=b=>createHash('sha256').update(b).digest('hex');
const source=await readFile(resolve(folder,'standing-source.png')),meta=await sharp(source).metadata();
const baselinePath='docs/design/characters/wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png';
const conceptPath='docs/design/characters/wang-lin-chibi-walk-v1/south-source-v1.png';
const palettePath='docs/design/characters/wang-lin-chibi-walk-v1/native-v2/atlas.json';
const baseline=await readFile(baselinePath),palette=JSON.parse(await readFile(palettePath,'utf8')).palette;
assert.equal(palette.length,24);
const colors=palette.slice(1).map(hex=>[1,3,5].map(start=>parseInt(hex.slice(start,start+2),16)));
const raw=await sharp(source).ensureAlpha().raw().toBuffer({resolveWithObject:true});
let left=raw.info.width,top=raw.info.height,right=-1,bottom=-1,zero=0;
for(let y=0;y<raw.info.height;y++)for(let x=0;x<raw.info.width;x++){
 const a=raw.data[(y*raw.info.width+x)*4+3];if(a===0)zero++;
 if(a>=128){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);}
}
assert.ok(meta.hasAlpha&&zero>raw.info.width*raw.info.height*.1&&right>left,'true alpha source');
const crop={left,top,width:right-left+1,height:bottom-top+1};
const web=await sharp(source).webp({quality:94,alphaQuality:100}).toBuffer();
const reduced=await sharp(source).extract(crop).resize({width:64,height:80,fit:'inside',kernel:'nearest'}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
// Mechanical native export only: nearest sampling, current palette and binary alpha.
// Anatomy, costume and pixels are generated in the source; this script does not draw them.
for(let i=0;i<reduced.data.length;i+=4){
 if(reduced.data[i+3]<128){reduced.data.fill(0,i,i+4);continue;}
 let best=colors[0],distance=Infinity;
 for(const c of colors){const d=.299*(reduced.data[i]-c[0])**2+.587*(reduced.data[i+1]-c[1])**2+.114*(reduced.data[i+2]-c[2])**2;if(d<distance){distance=d;best=c;}}
 reduced.data.set([...best,255],i);
}
// Place measured shoes at the current sprite's inclusive contact row y=88.
let shoeLeft=reduced.info.width,shoeRight=-1;
for(let y=Math.max(0,reduced.info.height-5);y<reduced.info.height;y++)for(let x=0;x<reduced.info.width;x++)if(reduced.data[(y*reduced.info.width+x)*4+3]){shoeLeft=Math.min(shoeLeft,x);shoeRight=Math.max(shoeRight,x);}
assert.ok(shoeRight>=shoeLeft,'ground-contact pixels');
const footCenter=(shoeLeft+shoeRight)/2,placement={left:Math.round(32-footCenter),top:89-reduced.info.height};
assert.ok(placement.left>=0&&placement.left+reduced.info.width<=64);
const reducedPng=await sharp(reduced.data,{raw:{width:reduced.info.width,height:reduced.info.height,channels:4}}).png().toBuffer();
const study=await sharp({create:{width:64,height:96,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite([{input:reducedPng,...placement}]).png({palette:true,colours:24,dither:0,effort:10}).toBuffer();
const decoded=await sharp(study).ensureAlpha().raw().toBuffer({resolveWithObject:true}),allowed=new Set(palette.map(h=>h.toUpperCase())),used=new Set(),alphas=new Set();let nativeBottom=-1;
for(let y=0;y<96;y++)for(let x=0;x<64;x++){
 const i=(y*64+x)*4,v=[...decoded.data.subarray(i,i+4)],hex='#'+v.map(c=>c.toString(16).padStart(2,'0')).join('').toUpperCase();
 alphas.add(v[3]);if(v[3]){assert.ok(allowed.has(hex),'locked native palette');nativeBottom=Math.max(nativeBottom,y);}used.add(v[3]?hex:'#00000000');
}
assert.deepEqual([...alphas].sort((a,b)=>a-b),[0,255]);assert.ok(used.size<=24);assert.equal(study[25],3,'indexed PNG');assert.equal(nativeBottom,88,'same contact row as baseline');
assert.ok(reduced.info.width>=43&&reduced.info.width<=47,'current broad chibi proportions');
await writeFile(resolve(folder,'standing.webp'),web);await writeFile(resolve(folder,'standing-study.png'),study);await copyFile(baselinePath,resolve(folder,'baseline.png'));
const manifest={date:'2026-10-11',id:'CHR-WANG-LIN-PIXEL-REVIEW-02',sourceCharacterId:'CHR-WANG-LIN',costume:'gray',status:'pending-owner-art-review',ownerApproved:false,artApproved:false,tool:'built-in image_gen',prompt:'standing.prompt.txt',directionDecision:{evidence:'sau 2 lần sửa tôi thấy không ổn bằng vương lâm hiện hành. Tôi cần bạn thiết kế lại vương lâm mới theo concept mà vương lâm hiện hành đang có.',scope:'Faithful redesign derived directly from the existing chibi source; prior two revisions were rejected.'},source:{file:'standing-source.png',size:[meta.width,meta.height],sha256:hash(source),alpha:true,crop},inputs:[{path:conceptPath,sha256:hash(await readFile(conceptPath)),role:'Primary existing chibi concept, first south idle extracted without redraw',derivedFile:'reference-chibi-source.png',derivedSha256:hash(await readFile(resolve(folder,'reference-chibi-source.png'))),crop:{left:0,top:0,width:512,height:512}},{path:baselinePath,sha256:hash(baseline),role:'Exact current native silhouette/pixel density; nearest 8x input, not natural-proportion concept',derivedFile:'reference-native-8x.png',derivedSha256:hash(await readFile(resolve(folder,'reference-native-8x.png'))),resize:{width:512,height:768,kernel:'nearest'}}],contract:{framePx:[64,96],anchorPx:[32,88],bodyPx:[reduced.info.width,reduced.info.height],placementPx:placement,measuredFootCenterLocalX:footCenter,measuredShoeRangeLocalX:[shoeLeft,shoeRight],groundPixelY:nativeBottom,paletteSource:palettePath,palette,usedColors:used.size,alphaValues:[0,255],format:'indexed_png',resampling:'nearest',defaultCameraZoom:1,productionNative:false,pixelFormatValidated:true,runtimeIntegrated:false,availableDirections:['south'],animation:false},assets:[{id:'standing',file:'standing.webp',sha256:hash(web),bytes:web.length,role:'Revised chibi concept source preview'},{id:'standing-study',file:'standing-study.png',size:[64,96],anchorPx:[32,88],sha256:hash(study),bytes:study.length,role:'Single native-format south idle study, pending visual review'},{id:'baseline',file:'baseline.png',size:[64,96],anchorPx:[32,88],sha256:hash(baseline),bytes:baseline.length,role:'Current Wang Lin copied unchanged'}]};
const reference=await readFile(resolve(folder,'reference-chibi-source.png'));
manifest.assets.push({id:'reference-chibi-source',file:'reference-chibi-source.png',size:[512,512],sha256:hash(reference),bytes:reference.length,role:'Unredrawn first idle crop from current chibi source'});
try{const p=JSON.parse(await readFile(resolve(folder,'assets.json'),'utf8'));if(p.source?.sha256===manifest.source.sha256)for(const key of ['status','ownerApproved','artApproved','approval'])if(p[key]!==undefined)manifest[key]=p[key];}catch(e){if(e.code!=='ENOENT')throw e;}
await writeFile(resolve(folder,'assets.json'),JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify({source:manifest.source.size,crop,body:manifest.contract.bodyPx,frame:[64,96],anchor:[32,88],placement,footCenter,nativeBottom,usedColors:used.size,alpha:[...alphas],indexed:true}));
