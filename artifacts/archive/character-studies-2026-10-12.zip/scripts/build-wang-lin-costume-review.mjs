import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);let sharp;
try{sharp=require('sharp');}catch{sharp=require(resolve(process.env.USERPROFILE??process.env.HOME,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp'));}
const folder='docs/design/characters/wang-lin-costume-review-v1',hash=b=>createHash('sha256').update(b).digest('hex');
const regions=JSON.parse(await readFile(folder+'/edit-regions.json','utf8'));
const baseline=await readFile(folder+'/baseline.png'),original=await readFile(regions.baselinePath);
assert.equal(hash(baseline),regions.baselineHash);assert.equal(hash(original),regions.baselineHash);
const base=await sharp(baseline).ensureAlpha().raw().toBuffer({resolveWithObject:true});
const mask=await sharp(folder+'/garment-mask.png').ensureAlpha().raw().toBuffer({resolveWithObject:true});
const source=await readFile(folder+'/costume-source.png'),sourceMeta=await sharp(source).metadata();
assert.equal(sourceMeta.width/sourceMeta.height,64/96,'source must retain full reference frame; never recrop or scale the actor by its bounds');
const paint=await sharp(source).resize(64,96,{kernel:'nearest',fit:'fill'}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
const costumePalette=['#243E42','#355459','#4E696D','#6C8282','#8F9E9A','#ABB7AC','#ADA59A','#D0C7B5','#EFE5D1','#8B7857','#B9A57C'];
const colors=costumePalette.map(h=>[1,3,5].map(k=>parseInt(h.slice(k,k+2),16)));
const out=Buffer.from(base.data);let changed=0,editable=0;
// Assemble the generated fabric layer into an immutable native base. No head/body resampling.
for(let i=0;i<out.length;i+=4){
 if(mask.data[i]!==255)continue;editable++;
 assert.equal(base.data[i+3],255,'fabric mask must never add silhouette pixels');
 assert.ok(paint.data[i+3]>=128,'generated fabric covers its authored location');
 let best=colors[0],distance=Infinity;
 for(const c of colors){const d=.299*(paint.data[i]-c[0])**2+.587*(paint.data[i+1]-c[1])**2+.114*(paint.data[i+2]-c[2])**2;if(d<distance){distance=d;best=c;}}
 out.set(best,i);if(!out.subarray(i,i+4).equals(base.data.subarray(i,i+4)))changed++;
}
assert.equal(editable,regions.editablePixels);assert.ok(changed>300,'visible costume change');
const study=await sharp(out,{raw:{width:64,height:96,channels:4}}).png({compressionLevel:9}).toBuffer();
const decoded=await sharp(study).ensureAlpha().raw().toBuffer({resolveWithObject:true});
assert.ok(decoded.data.equals(out),'lossless RGBA packing must preserve exact locked pixels');
let protectedChanges=0,headChanges=0,skinChanges=0,shoeChanges=0,alphaChanges=0,left=64,top=96,right=-1,bottom=-1;const used=new Set();
const skin=new Set(['#A96850','#CC9873','#E5B88F','#F2CEA6']);
for(let y=0;y<96;y++)for(let x=0;x<64;x++){
 const i=(y*64+x)*4,a=base.data.subarray(i,i+4),b=decoded.data.subarray(i,i+4),different=!a.equals(b),rgb='#'+[...a.subarray(0,3)].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();
 if(different&&mask.data[i]!==255)protectedChanges++;
 if(different&&y<=49)headChanges++;if(different&&skin.has(rgb))skinChanges++;if(different&&y>=82)shoeChanges++;
 if(a[3]!==b[3])alphaChanges++;if(b[3]){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);}
 used.add([...b].join(','));
}
assert.deepEqual([protectedChanges,headChanges,skinChanges,shoeChanges,alphaChanges],[0,0,0,0,0]);assert.deepEqual([left,top,right-left+1,bottom-top+1],[9,9,45,80]);
await writeFile(folder+'/standing-study.png',study);
const preview=await sharp(study).resize(512,768,{kernel:'nearest'}).png().toBuffer();await writeFile(folder+'/costume-preview.png',preview);
const baselinePreview=await sharp(baseline).resize(512,768,{kernel:'nearest'}).png().toBuffer();await writeFile(folder+'/baseline-preview.png',baselinePreview);
// Raw source may differ outside the fabric guide; it is archived, never shown as a new face.
const checks={editablePixels:editable,changedFabricPixels:changed,protectedPixelChanges:protectedChanges,headPixelChanges:headChanges,skinPixelChanges:skinChanges,shoePixelChanges:shoeChanges,alphaPixelChanges:alphaChanges,exactNativeBounds:[left,top,right-left+1,bottom-top+1],losslessRgba:true};
const assets=[['standing-study','standing-study.png',study,[64,96]],['baseline','baseline.png',baseline,[64,96]],['costume-preview','costume-preview.png',preview,[512,768]],['baseline-preview','baseline-preview.png',baselinePreview,[512,768]]].map(([id,file,bytes,size])=>({id,file,size,sha256:hash(bytes),bytes:bytes.length}));
const manifest={date:'2026-10-11',id:'CHR-WANG-LIN-COSTUME-REVIEW-01',sourceCharacterId:'CHR-WANG-LIN',scope:'Costume fabric only on current immutable Wang Lin sprite',costume:'van-ngoc-gray-jade-study',status:'pending-owner-costume-review',ownerApproved:false,artApproved:false,tool:'built-in image_gen',prompt:'costume.prompt.txt',directionDecision:{evidence:'tỷ lệ chibi hiện hành đã tốt rồi chỉ cần thay đổi trang phục và concpet mới thôi',locks:'Exact existing head, face, hair, limbs, skin, shoes, alpha silhouette, native size and anchor; no regenerated body'},source:{file:'costume-source.png',size:[sourceMeta.width,sourceMeta.height],sha256:hash(source),role:'Generated garment paint; non-garment pixels discarded',fullFrameSampling:true,crop:false},inputs:[{file:'edit-target-16x.png',sha256:hash(await readFile(folder+'/edit-target-16x.png')),role:'Existing native sprite enlarged exactly 16x, edit target',originalPath:regions.baselinePath,originalSha256:regions.baselineHash},{file:'garment-mask-16x.png',sha256:hash(await readFile(folder+'/garment-mask-16x.png')),role:'Fabric-only edit guide; white allowed, black locked'}],mask:{file:'garment-mask.png',sha256:hash(await readFile(folder+'/garment-mask.png')),regionsFile:'edit-regions.json'},contract:{framePx:[64,96],anchorPx:[32,88],bodyPx:[45,80],placementPx:{left:9,top:9},defaultCameraZoom:1,bodyResampling:false,sourceSampling:'full frame nearest only inside garment mask',alphaValues:[0,255],palette:'Original protected pixels plus dedicated garment colors',costumePalette,usedColors:used.size,format:'rgba_png',runtimeIntegrated:false,animation:false,availableDirections:['south']},checks,assets};
try{const prior=JSON.parse(await readFile(folder+'/assets.json','utf8'));if(prior.source?.sha256===manifest.source.sha256)for(const key of ['status','ownerApproved','artApproved','approval'])if(prior[key]!==undefined)manifest[key]=prior[key];}catch(e){if(e.code!=='ENOENT')throw e;}
await writeFile(folder+'/assets.json',JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify(checks));
