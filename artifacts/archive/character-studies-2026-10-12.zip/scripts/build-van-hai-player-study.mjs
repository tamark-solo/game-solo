import {readFile,writeFile,mkdir} from 'node:fs/promises';import {createHash} from 'node:crypto';import {createRequire} from 'node:module';import {resolve} from 'node:path';
const require=createRequire(import.meta.url);let sharp;try{sharp=require('sharp');}catch{sharp=require(resolve(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp'));}
const folder=resolve('docs/design/characters/van-hai-player-v1'),publicFolder=resolve('client/public/assets/van-hai-player-v1');await mkdir(publicFolder,{recursive:true});
const hash=data=>createHash('sha256').update(data).digest('hex');const assets=[];
for(const name of ['concept','ui-figure','game-standing']){
 const source=await readFile(resolve(folder,name+'-source.png')),meta=await sharp(source).metadata();let pipeline=sharp(source),crop;
 if(name!=='concept'){
  if(!meta.hasAlpha)throw new Error('Transparent source required: '+name);
  const {data,info}=await sharp(source).ensureAlpha().raw().toBuffer({resolveWithObject:true});let left=info.width,top=info.height,right=-1,bottom=-1,zero=0,maxAlpha=0;
  for(let y=0;y<info.height;y++)for(let x=0;x<info.width;x++){const a=data[(y*info.width+x)*4+3];maxAlpha=Math.max(maxAlpha,a);if(a===0)zero++;if(a>8){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);}}
  if(zero<info.width*info.height*.1||maxAlpha<240)throw new Error('Invalid transparency: '+name);
  // Add source padding; preserve generated alpha. No repaint or background removal.
  left=Math.max(0,left-6);top=Math.max(0,top-6);right=Math.min(info.width-1,right+6);bottom=Math.min(info.height-1,bottom+6);
  crop={left,top,width:right-left+1,height:bottom-top+1};pipeline=sharp(source).extract(crop);
 }
 const web=await pipeline.resize({width:name==='concept'?1536:undefined,height:name==='concept'?undefined:1024,withoutEnlargement:true,kernel:'lanczos3'}).webp({quality:94,alphaQuality:100}).toBuffer();await writeFile(resolve(folder,name+'.webp'),web);await writeFile(resolve(publicFolder,name+'.webp'),web);const webMeta=await sharp(web).metadata();
 assets.push({id:name,source:name+'-source.png',sourceSize:[meta.width,meta.height],sourceSha256:hash(source),web:name+'.webp',size:[webMeta.width,webMeta.height],bytes:web.length,sha256:hash(web),crop,hasAlpha:!!webMeta.hasAlpha});
 if(name==='game-standing'){
  // One resampled pose to assess scale. It is not a production pixel/animation atlas.
  const scaled=await sharp(source).extract(crop).resize({height:80,width:64,fit:'inside',kernel:'lanczos3'}).png().toBuffer(),sm=await sharp(scaled).metadata();const left=Math.round(32-sm.width/2),top=88-sm.height;
  const native=await sharp({create:{width:64,height:96,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite([{input:scaled,left,top}]).png().toBuffer();await writeFile(resolve(folder,'standing-scale-study.png'),native);await writeFile(resolve(publicFolder,'standing-scale-study.png'),native);
  assets.push({id:'standing-scale-study',file:'standing-scale-study.png',size:[64,96],anchorPx:[32,88],bodyResamplePx:[sm.width,sm.height],sourceId:name,sha256:hash(native),bytes:native.length,hasAlpha:true,production:false,format:'painted-resample-only'});
 }
}
const references=[];for(const [path,role] of [['docs/design/world/hang-nhac-van-ngoc-concept-v1/concept.webp','inspected style reference; described in text, no image input to first generation'],['docs/design/characters/van-hai-player-v1/refs/ui-context.png','inspected UI material reference; described in text'],['docs/design/characters/van-hai-player-v1/concept-source.png','identity image input for the two alpha derivatives']])references.push({path,role,sha256:hash(await readFile(path))});
const manifest={date:'2026-10-11',id:'VHD-PLAYER-CONCEPT-01',name:'Người chơi Vân Hải · nhập môn',scope:'Original player identity study requested by owner; male first, not a roster/character-ID migration',status:'owner-rejected-art-direction',ownerFeedback:{date:'2026-10-11',text:'nhìn khá kỳ không đẹp và ổn như concept cũ của tôi',reference:'Bảng tạo hình áo xám/áo đỏ'},tool:'built-in image_gen',ownerApproved:false,artApproved:false,identityIndependent:true,prompts:['concept.prompt.txt','ui-figure.prompt.txt','game-standing.prompt.txt'],references,assets,gameContract:{framePx:[64,96],anchorPx:[32,88],cameraScale:1},sourceNotes:{concept:'Identity illustration in adult proportions; not three-head runtime artwork',gameStanding:'Compact elevated three-quarter source; exact south view and four-direction consistency remain to be authored',alpha:'Generated alpha is soft; not the legacy 24-entry binary-alpha native format'},runtimeIntegrated:false,profileMigration:false,ownerMapModified:false};
await writeFile(resolve(folder,'assets.json'),JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify(assets.map(({id,size,bytes})=>({id,size,bytes}))));
