import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);let sharp;
try{sharp=require('sharp');}catch{sharp=require(resolve(process.env.USERPROFILE??process.env.HOME,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp'));}
const folder=resolve('docs/design/characters/wang-lin-pixel-review-v1'),hash=b=>createHash('sha256').update(b).digest('hex');
const sourceFile='standing-source-v2.png',source=await readFile(resolve(folder,sourceFile)),meta=await sharp(source).metadata();
const baselinePath='docs/design/characters/wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png',palettePath='docs/design/characters/wang-lin-chibi-walk-v1/native-v2/atlas.json',identityPath='docs/design/characters/wang-lin-initiation-v2.png';
const baseline=await readFile(baselinePath),palette=JSON.parse(await readFile(palettePath,'utf8')).palette;
assert.equal(palette.length,24);
const colors=palette.slice(1).map(hex=>[1,3,5].map(start=>parseInt(hex.slice(start,start+2),16)));
const raw=await sharp(source).ensureAlpha().raw().toBuffer({resolveWithObject:true});
let left=raw.info.width,top=raw.info.height,right=-1,bottom=-1,zero=0;
for(let y=0;y<raw.info.height;y++)for(let x=0;x<raw.info.width;x++){
 const a=raw.data[(y*raw.info.width+x)*4+3];if(a===0)zero++;
 if(a>=128){left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);}
}
assert.ok(meta.hasAlpha&&zero>raw.info.width*raw.info.height*.1&&right>left,'true alpha source');
const crop={left,top,width:right-left+1,height:bottom-top+1};
const web=await sharp(source).extract(crop).resize({height:1024,withoutEnlargement:true}).webp({quality:94,alphaQuality:100}).toBuffer();
const reduced=await sharp(source).extract(crop).resize({width:64,height:80,fit:'inside',kernel:'nearest'}).ensureAlpha().raw().toBuffer({resolveWithObject:true});
// Standard native export, following the current Wang Lin pack: nearest sampling,
// locked palette, binary alpha. No hand-drawn pixels, anatomy edits or synthesized poses.
for(let i=0;i<reduced.data.length;i+=4){
 if(reduced.data[i+3]<128){reduced.data.fill(0,i,i+4);continue;}
 let best=colors[0],distance=Infinity;
 for(const c of colors){const d=.299*(reduced.data[i]-c[0])**2+.587*(reduced.data[i+1]-c[1])**2+.114*(reduced.data[i+2]-c[2])**2;if(d<distance){distance=d;best=c;}}
 reduced.data.set([...best,255],i);
}
// Measure the midpoint of the bottom shoe pixels rather than treating image center as feet.
let shoeLeft=reduced.info.width,shoeRight=-1;
for(let y=Math.max(0,reduced.info.height-5);y<reduced.info.height;y++)for(let x=0;x<reduced.info.width;x++)if(reduced.data[(y*reduced.info.width+x)*4+3]){shoeLeft=Math.min(shoeLeft,x);shoeRight=Math.max(shoeRight,x);}
assert.ok(shoeRight>=shoeLeft,'ground-contact pixels');
const footCenter=(shoeLeft+shoeRight)/2,placement={left:Math.round(32-footCenter),top:88-reduced.info.height};
assert.ok(placement.left>=0&&placement.left+reduced.info.width<=64);
const reducedPng=await sharp(reduced.data,{raw:{width:reduced.info.width,height:reduced.info.height,channels:4}}).png().toBuffer();
const study=await sharp({create:{width:64,height:96,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite([{input:reducedPng,...placement}]).png({palette:true,colours:24,dither:0,effort:10}).toBuffer();
const decoded=await sharp(study).ensureAlpha().raw().toBuffer({resolveWithObject:true}),allowed=new Set(palette.map(h=>h.toUpperCase())),used=new Set(),alphas=new Set();
let nativeBottom=-1;
for(let y=0;y<96;y++)for(let x=0;x<64;x++){
 const i=(y*64+x)*4,v=[...decoded.data.subarray(i,i+4)],hex='#'+v.map(c=>c.toString(16).padStart(2,'0')).join('').toUpperCase();
 alphas.add(v[3]);if(v[3]){assert.ok(allowed.has(hex),'locked native palette');nativeBottom=Math.max(nativeBottom,y);}used.add(v[3]?hex:'#00000000');
}
assert.deepEqual([...alphas].sort((a,b)=>a-b),[0,255]);assert.ok(used.size<=24);assert.equal(study[25],3,'indexed PNG');assert.equal(nativeBottom,87,'ground line immediately above y=88');
await writeFile(resolve(folder,'standing.webp'),web);await writeFile(resolve(folder,'standing-study.png'),study);await copyFile(baselinePath,resolve(folder,'baseline.png'));
const manifest={date:'2026-10-11',id:'CHR-WANG-LIN-PIXEL-REVIEW-01',sourceCharacterId:'CHR-WANG-LIN',costume:'gray',status:'pending-owner-art-review',ownerApproved:false,artApproved:false,tool:'built-in image_gen',prompt:'standing-v2.prompt.txt',directionDecision:{evidence:'concept mới nhìn ổn nhưng chưa bán theo nhân vật vương lâm của cốt truyện',scope:'Return to Wang Lin initiation identity and current chibi pixel treatment; not acceptance of newly generated art.'},source:{file:sourceFile,size:[meta.width,meta.height],sha256:hash(source),alpha:true,crop},sourceHistory:[{path:'docs/design/characters/wang-lin-pixel-review-v1/standing-source.png',prompt:'standing.prompt.txt',sha256:hash(await readFile(resolve(folder,'standing-source.png'))),role:'Initial pixel source, edited to simplify clusters in current v2'}],inputs:[{path:baselinePath,sha256:hash(baseline),role:'Primary Wang Lin identity, chibi proportions, pixel clusters and elevated south camera'},{path:identityPath,sha256:hash(await readFile(identityPath)),role:'Approved Wang Lin initiation v2, middle gray robe and youthful face; not natural body proportions'}],contract:{framePx:[64,96],anchorPx:[32,88],bodyPx:[reduced.info.width,reduced.info.height],placementPx:placement,measuredFootCenterLocalX:footCenter,measuredShoeRangeLocalX:[shoeLeft,shoeRight],groundPixelY:nativeBottom,paletteSource:palettePath,palette,usedColors:used.size,alphaValues:[0,255],format:'indexed_png',resampling:'nearest',defaultCameraZoom:1,productionNative:false,pixelFormatValidated:true,runtimeIntegrated:false,availableDirections:['south'],animation:false},assets:[{id:'standing',file:'standing.webp',sha256:hash(web),bytes:web.length,role:'Generated source preview'},{id:'standing-study',file:'standing-study.png',size:[64,96],anchorPx:[32,88],sha256:hash(study),bytes:study.length,role:'One pixel-native idle south art study; no animation approval'},{id:'baseline',file:'baseline.png',size:[64,96],anchorPx:[32,88],sha256:hash(baseline),bytes:baseline.length,role:'Current Wang Lin, copied unchanged'}]};
try{const p=JSON.parse(await readFile(resolve(folder,'assets.json'),'utf8'));if(p.source?.sha256===manifest.source.sha256)for(const key of ['status','ownerApproved','artApproved','approval'])if(p[key]!==undefined)manifest[key]=p[key];}catch(e){if(e.code!=='ENOENT')throw e;}
await writeFile(resolve(folder,'assets.json'),JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify({source:manifest.source.size,crop,body:manifest.contract.bodyPx,frame:[64,96],anchor:[32,88],placement,footCenter,nativeBottom,usedColors:used.size,alpha:[...alphas],indexed:true,ownerApproved:manifest.ownerApproved}));
