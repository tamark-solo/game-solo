# Chibi Vân Hải 01 · từ concept nhận diện 02

**Đã chuyển ưu tiên nhận diện:** owner nhận xét chibi hiện hành hợp map hơn nhờ pixel, và concept mới chưa bám Vương Lâm. [Mẫu Vương Lâm pixel](../wang-lin-pixel-review-v1/README.md) đang là mặc định. Bộ này giữ làm nghiên cứu nhận diện riêng trong lựa chọn; không đổi tên hình/mặt/tóc này thành Vương Lâm.

**11/10/2026 · chờ đánh giá hình.** Sau khi so mẫu dáng thanh 02 với chibi trên map, owner đồng ý hướng **chibi tu tiên dáng thanh, nét tiết chế**, giữ mặt/tóc/áo riêng của concept 02, và yêu cầu đặt cạnh chibi hiện hành. Xác nhận hướng không tự duyệt hình mới hoặc bộ sprite sản xuất.

[Xem cạnh chibi hiện hành](http://127.0.0.1:5174/van-hai-character-review.html?view=map): **Chibi Vân Hải mới bên trái**, chibi hiện hành bên phải, cùng frame **64 × 96**, chân **(32,88)** và camera **1×**. Có đổi nền Vân Ngọc/ảnh tổng quan Hằng Nhạc, năm điểm xem, zoom/pan và frame/neo. Mục **Mẫu mới** giữ bản dáng thanh trước để so lại; mặc định là chibi mới.

## Tạo hình

- Tóc buộc thấp, mặt trẻ có ánh nhìn bình tĩnh; đầu lớn hơn bản dáng thanh, tiết chế hơn chibi hiện hành có búi tóc/tóc xòe lớn.
- Áo xám ngọc nhập môn, cổ áo ngà, đai vải than, quần tối, băng chân và giày vải. Giữ bàn tay và khoảng chân rõ, không thêm trang bị/hoa văn/linh quang.
- Khối tóc/mặt/cổ/đai và đường viền mực được làm gọn để đọc ở thân cao khoảng 80 px; dáng có cùng chiều cao hiển thị với chibi so sánh.

## Nguồn

| File | Vai trò |
| --- | --- |
| [standing-source.png](standing-source.png) | PNG ImageGen gốc 1024 × 1536, alpha thật |
| [standing.prompt.txt](standing.prompt.txt) | Prompt đầy đủ, vai trò hai input và giới hạn hình |
| [standing.webp](standing.webp) | Bản nguồn thu/crop để xem, không dùng phóng như sprite native |
| [standing-study.png](standing-study.png) | Một pose đứng Nam, frame 64 × 96; thu thân 35 × 80, neo (32,88) |
| [baseline.png](baseline.png) | Sao chép nguyên byte từ chibi hiện hành |
| [assets.json](assets.json) | Source/input/crop/hash, frame/neo, phạm vi và trạng thái duyệt |

Công cụ: skill **imagegen**, **built-in image_gen**, `transparent_background: true`. Input nhận diện là [concept 02](../van-hai-player-v2/concept-source.png); input [sprite Nam cũ](../wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png) chỉ cho camera/silhouette/độ rõ, không sao chép nhận diện. PNG được sao chép từ `$CODEX_HOME/generated_images` vào workspace; gốc ImageGen được giữ nguyên.

`scripts/build-van-hai-player-chibi-v1.mjs` chỉ kiểm alpha, crop theo bounds alpha >8 thêm 4 px, resample giữ tỷ lệ và đặt frame; không vẽ raster bằng code. Crop (246,171,533,1234), thu 35 × 80, vị trí trên frame (15,8); không kéo rộng hoặc phóng riêng người để tạo cảm giác rõ hơn. Sync kiểm hash từng file trước đưa vào public. Đóng gói lại nguồn không đổi giữ quyết định ART; thay nguồn yêu cầu đánh giá mới.

## Giới hạn và kiểm

Một pose nghiên cứu tỷ lệ/độ rõ, alpha mềm và nhiều màu; chưa palette pixel 24 mục/alpha nhị phân, animation, bộ đứng bốn hướng hoặc atlas production. Không đổi ID/profile/save/avatar runtime, renderer, camera game hay map/navigation. Review dùng DOM cùng phép chiếu orthographic; ảnh tổng quan không kiểm mái/tán che người. Phạm vi map ở [hồ sơ đối chiếu](../../../VAN-HAI-CHARACTER-MAP-REVIEW.md).

[Bằng chứng kỹ thuật](../../../data/van-hai-player-chibi-v1-verification.json): sáu viewport/30 bố cục, chọn chibi/dáng thanh không đổi zoom/điểm/frame/mẫu cũ, camera/neo, kéo/chạm/keyboard/expand; không ghi storage/API/game websocket. Typecheck/boundary, Vite build và HUD/layer fixture qua. Hình mới vẫn `ownerApproved: false`, `artApproved: false`.
