# Vương Lâm · thiết kế lại từ concept chibi hiện hành

**Làm rõ mới nhất:** tỷ lệ chibi hiện hành đã tốt, chỉ đổi trang phục. Bản này bị bác vì vẫn vẽ lại người và mặt. `status: rejected-by-owner`; [bản trang phục](../wang-lin-costume-review-v1/README.md) khóa native gốc và chỉ ghép vải. Kiểm kỹ thuật bên dưới giữ lịch sử, không chứng minh hình người được chấp nhận.

**11/10/2026 · đã dừng theo phản hồi owner.** Owner nhận xét: “sau 2 lần sửa tôi thấy không ổn bằng vương lâm hiện hành”, và yêu cầu thiết kế lại Vương Lâm mới theo concept hiện hành. Hai source của [review 01](../wang-lin-pixel-review-v1/README.md) được ghi **chưa đạt**, không tiếp tục làm chuẩn nhận diện. Bản 02 lấy chính **source chibi đang dùng** làm tham chiếu chính, thay vì đưa vóc dáng tự nhiên của bảng chân dung vào sprite.

[Trang đối chiếu](http://127.0.0.1:5174/van-hai-character-review.html): phía trên là source mới bên trái/source chibi gốc bên phải, cùng hai PNG phóng nearest 2×. [Vùng map](http://127.0.0.1:5174/van-hai-character-review.html?view=map) mặc định **Vương Lâm · từ chibi gốc** bên trái và sprite hiện hành bên phải, camera **1×**.

## Giữ và chỉnh

| Thành phần | Thiết kế 02 |
| --- | --- |
| Nhận diện | Cùng mặt thiếu niên, mắt tập trung, mái tóc lệch, tóc đen buộc cao bằng vải ngà và phần tóc dài thả hai bên |
| Tỷ lệ | Đầu lớn/thân gọn, vai và tà áo rộng như chibi hiện hành; không kéo thân mảnh hoặc thu mặt |
| Áo xám | Giữ cổ/ngực sáng, nẹp chéo tối, đai vải và giày tối; làm rõ khối tay áo, cuff, panel giữa và tà đai |
| Pixel | Nhóm sáng/tối rõ, số nếp áo tiết chế; palette và frame hiện hành |
| Phạm vi | Một pose đứng Nam; chưa sản xuất đứng bốn hướng, đi hoặc thi triển |

Đây là ART tiếp nối concept chibi đã chọn. Không bổ sung chi tiết nguyên tác mới, không sử dụng diện mạo hoạt hình/game khác. Nhận diện v2 trong [hồ sơ](../../../WANG-LIN-VISUAL-SPEC.md) tiếp tục làm căn cứ nhân vật/trang phục; **source chibi** quyết định tỷ lệ và hình khi chơi.

## Source, input và export

| File | Vai trò |
| --- | --- |
| [standing-source.png](standing-source.png) | Source mới, built-in **image_gen**, alpha thật, 1254 × 1254 |
| [standing.prompt.txt](standing.prompt.txt) | Prompt chính xác và vai trò hai input |
| [reference-chibi-source.png](reference-chibi-source.png) | Crop nguyên pose đầu Nam từ source hiện hành, rectangle (0,0,512,512), không vẽ lại |
| [reference-native-8x.png](reference-native-8x.png) | Frame hiện hành phóng nearest 8× để công cụ giữ silhouette/cụm màu |
| [standing.webp](standing.webp) | Preview source mới trong trang concept |
| [standing-study.png](standing-study.png) | PNG indexed cỡ chơi 64 × 96, đang review |
| [baseline.png](baseline.png) | PNG hiện hành sao chép nguyên byte |
| [assets.json](assets.json) | Source/input/hash, crop, palette, điểm chân và trạng thái |

Source gốc input là [south-source-v1.png](../wang-lin-chibi-walk-v1/south-source-v1.png) và [frame native-v2](../wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png). Bản tạo mới được sao chép vào workspace từ `$CODEX_HOME/generated_images`; trang không phụ thuộc đường dẫn ngoài workspace.

Exporter `scripts/build-wang-lin-pixel-review-v2.mjs` chỉ cắt theo alpha, lấy mẫu **nearest**, map vào palette 24 mục hiện hành, đóng alpha 0/255 và PNG indexed; không vẽ giải phẫu hoặc synthesize pose. Crop source (323,55,675,1167), thu giữ tỷ lệ **46 × 80**, đặt tại **(8,9)** trong frame **64 × 96**. Sprite hiện hành có bounds **45 × 80**, top 9. Cả hai hàng tiếp đất cuối **y=88**, neo **(32,88)**; đo trung điểm giày mới local x=24,5, sau đặt x=32,5, không dùng tâm bounds làm chân.

## Kiểm và giới hạn

[Bằng chứng kỹ thuật](../../../data/wang-lin-pixel-review-v2-verification.json): sáu viewport, 42 bố cục, 924 kiểm; có source/native pair, bốn mẫu chọn, zoom/pan/đổi nền, frame/neo và mở lớn. Không lỗi console/network, không request gameplay/WebSocket game hoặc ghi local/session storage trong profile test. Typecheck/boundary và Vite build qua; PNG/public/source hash khớp và baseline giữ nguyên. Đã xem concept, native phóng, sân sáng và vườn tùng ở 1×/2×.

Map review vẫn là phép so ART bằng DOM, dùng nền concept 1536 × 1024 đặt 2× hoặc ảnh overview runtime; chưa là phép kiểm live Three.js/mái-tán che người. Không sửa map/navigation/blocker/camera runtime hoặc save/DB/backend/GDD/roster. Bộ game giữ hiện hành. Không chạy lại hồi quy combat/HUD vì đợt này không đổi các phần đó.

`ownerApproved: false`, `artApproved: false`, `runtimeIntegrated: false`. Kiểm định format và nhận diện cũ đã duyệt không tự duyệt hình mới. Sau khi hình được đánh giá, mới tiếp tục nhiều hướng/chuyển động và kiểm body/VFX/layer theo Core.
