# Vương Lâm · chỉ đổi trang phục trên sprite hiện hành

**11/10/2026 · chờ đánh giá trang phục.** Owner làm rõ: “tỷ lệ chibi hiện hành đã tốt rồi chỉ cần thay đổi trang phục và concpet mới thôi”. Các bản vẽ lại người/mặt trước đã dừng. Chuẩn hiện tại là **giữ nguyên sprite Vương Lâm native-v2**, thiết kế mới chỉ trong vùng vải. Không lấy số đo frame giống nhau làm bằng chứng rằng người đã giữ nguyên.

[Mở trang so sánh](http://127.0.0.1:5174/van-hai-character-review.html): bên trái là trang phục Vân Ngọc mới, bên phải là trang phục hiện hành trên **cùng một người**. Hình trên phóng đồng tỷ lệ để xem pixel; [map](http://127.0.0.1:5174/van-hai-character-review.html?view=map) mặc định camera **1×**.

## Trang phục và phần được khóa

Thiết kế thử dùng vải **xám ngọc**, cổ/lớp trong **ngà**, nẹp **xanh trầm** và viền vải **đồng nhẹ**, giữ đai vải tối. Màu phục vụ map/UI Vân Ngọc; đây là ART trang phục, không thêm vật phẩm, chỉ số hay trang phục gameplay.

| Phần | Hợp đồng lần này |
| --- | --- |
| Đầu, mặt, tóc và nhận diện | Giữ pixel gốc; vùng y=0–49 không có pixel thay đổi, cụm tóc ngoài vùng vải được khóa |
| Da, bàn tay và giày | Giữ màu và tọa độ gốc; không có pixel thay đổi |
| Tỷ lệ, tư thế và silhouette | Giữ toàn bộ alpha từng pixel; bounds vẫn **(9,9,45,80)** |
| Frame và điểm chân | **64 × 96**, **(32,88)**; không crop/recenter/thu người theo bounds nguồn sinh |
| Vải được sửa | Mask 471 pixel của áo/cổ/tà; **366 pixel thực tế thay đổi** |

Đây là một pose đứng Nam. Mask chỉ đúng cho pose này, không áp vào mọi frame đi/cast. Nhiều hướng/động tác cần mask và lớp vải riêng theo frame, giữ Core/body/anchor hiện hành.

## File và cách xuất

| File | Vai trò |
| --- | --- |
| [standing-study.png](standing-study.png) | PNG cuối **64 × 96**, dùng trong review/map; người gốc + vùng vải mới |
| [costume-preview.png](costume-preview.png) | PNG cuối phóng nearest 8×; **không phải người do ImageGen vẽ lại** |
| [baseline.png](baseline.png), [baseline-preview.png](baseline-preview.png) | Sprite hiện hành nguyên byte và bản nearest 8× |
| [costume-source.png](costume-source.png) | Source ImageGen **1024 × 1536**; chỉ đọc vùng vải, pixel ngoài mask bị bỏ |
| [costume.prompt.txt](costume.prompt.txt) | Prompt chính xác của built-in **image_gen**; khóa người, chỉ sửa trang phục |
| [edit-target-16x.png](edit-target-16x.png) | Sprite hiện hành phóng nearest 16× làm edit target |
| [garment-mask.png](garment-mask.png), [mask 16×](garment-mask-16x.png) | Vùng vải được phép chỉnh; ngoài mask giữ nguyên |
| [garment-region-guide.png](garment-region-guide.png) | Hình chẩn đoán: màu xanh chỉ vùng sửa, không là ART trang phục |
| [edit-regions.json](edit-regions.json), [assets.json](assets.json) | Quy tắc vùng sửa, hash/input/source, kiểm pixel và trạng thái |

`scripts/prepare-wang-lin-costume-review.mjs` chuẩn bị input/mask từ [sprite gốc](../wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png), hash `ae9cfddb…a325`. `scripts/build-wang-lin-costume-review.mjs` lấy mẫu source theo **toàn frame**, chỉ ghép paint ImageGen trong mask vào bản sao native gốc; không vẽ body/face bằng code, không resize thân người. Màu mới chỉ map trong vải, không remap palette của phần được khóa.

PNG cuối dùng **RGBA lossless**, 32 màu dùng gồm trong suốt, 2103 byte. Giữ nguyên màu/pixel gốc là ưu tiên; không ép toàn sprite về palette 24 màu cũ khi thêm màu áo. Alpha vẫn **0/255**. Bản đóng indexed tự lượng tử hóa đã không qua so pixel, vì vậy không dùng. Bộ gốc không đổi format hoặc byte.

Source/prompt/input được lưu trong workspace từ built-in ImageGen; preview không phụ thuộc file ngoài workspace. Raw source có thể thay đổi pixel ngoài áo; source đó không được dùng làm concept khuôn mặt mới hoặc ảnh đại diện. Hai ảnh đối chiếu trên trang lấy từ PNG cuối và PNG gốc, cùng khung và mức phóng.

## Kiểm và trạng thái

[Bằng chứng](../../../data/wang-lin-costume-review-v1-verification.json): so từng pixel cho **0 thay đổi ngoài mask**, **0 đầu/mặt**, **0 da**, **0 giày**, **0 alpha**; bounds và điểm chân nguyên trạng. Sáu viewport/48 bố cục/978 kiểm trang, đổi mẫu/nền/zoom/frame/neo và phóng cùng tỷ lệ; không lỗi hoặc request gameplay/storage trong profile kiểm. Typecheck/boundary và Vite build qua. Kết quả kiểm giữ người không thay việc owner đánh giá thiết kế áo.

`ownerApproved: false`, `artApproved: false`, `runtimeIntegrated: false`. Chỉ bản thử trang phục một pose, chưa bộ đi/cast hay avatar game. Map/navigation/blocker/backend/save/DB/GDD/roster giữ nguyên. Bộ game vẫn dùng nguyên atlas hiện hành; không thay 20 frame bằng một hình đứng.
