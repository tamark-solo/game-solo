# Người chơi Vân Hải · nhập môn 01

**Hướng 01 đã dừng ngày 11/10:** owner phản hồi hình chưa đẹp bằng concept áo xám/áo đỏ cũ. [Bản 02](../van-hai-player-v2/README.md) là nghiên cứu hiện hành; hình alpha/native mẫu 01 giữ lịch sử và đã gỡ khỏi mặc định UI.

Owner chọn tạo nhận diện riêng cho Vân Hải ngày 11/10/2026. Đây là mẫu nam đầu tiên, **concept chờ đánh giá hình**, không tự thay ba avatar/profile runtime.

[Thiết kế và bước sản xuất](../../../VAN-HAI-PLAYER-IDENTITY-V1.md) · [Trang xem](http://127.0.0.1:5174/van-hai-character-review.html) · [Linh Đài](http://127.0.0.1:5174/ui-material-review.html?screen=character).

| Đầu ra | Source | Prompt | Web |
| --- | --- | --- | --- |
| Nhận diện | [PNG](concept-source.png) | [Prompt](concept.prompt.txt) | [WebP](concept.webp) |
| Linh ảnh UI alpha | [PNG](ui-figure-source.png) | [Prompt](ui-figure.prompt.txt) | [WebP](ui-figure.webp) |
| Game-body góc cao alpha | [PNG](game-standing-source.png) | [Prompt](game-standing.prompt.txt) | [WebP](game-standing.webp) |
| Mẫu cỡ chơi | Thu mẫu từ nguồn đứng | Export cơ học, không vẽ bằng code | [64 × 96 PNG](standing-scale-study.png) |

Công cụ: skill **imagegen** và **built-in image_gen**, không CLI fallback. [Metadata](assets.json) ghi input/role/hash, crop, canvas/anchor và trạng thái. Concept đầu là text-to-image theo phong cách map/UI đã xem; hai ảnh alpha dùng concept mới làm reference/edit input.

Giữ nguyên PNG gốc. Builder thu mẫu/copy sản phẩm trong workspace, sync kiểm hash. Mẫu một pose alpha mềm chưa là atlas 24 màu/binary alpha hoặc bộ chuyển động được duyệt; tỷ lệ/góc chính xác cần chốt trước bốn hướng. Frame mục tiêu 64 × 96 / chân (32,88) / camera 1× giữ nguyên.
