# Người chơi Vân Hải · nghiên cứu nhận diện 02

**Mẫu cỡ chơi hiện hành:** theo yêu cầu owner tiếp theo, đã có [Chibi Vân Hải 01](../van-hai-player-chibi-v1/README.md) từ mặt/tóc/áo concept 02. Review mặc định so chibi mới với chibi hiện hành; mẫu dáng thanh của thư mục này vẫn có trong mục chọn. Hướng concept 02 giữ phạm vi duyệt, không tự duyệt chibi mới hoặc animation.

**11/10/2026 · đã chấp nhận hướng concept, đang đối chiếu mẫu đứng.** Owner chọn **bảng áo xám/áo đỏ** làm mẫu nét, sau đó xác nhận “nhìn ổn đó giờ hãy đưa vào map để so sách tỷ lệ so với map và camera”. Duyệt này dành cho hướng concept 02, chưa duyệt sprite/animation sản xuất. Bản 01 đã dừng và gỡ khỏi linh ảnh mặc định; nguồn giữ làm lịch sử.

[Trang xem cùng URL hiện có](http://127.0.0.1:5174/van-hai-character-review.html): chọn Đề xuất mới / Concept cũ / Xem song song. Bản cũ được dùng làm tham chiếu nét vẽ, vóc dáng và độ giản dị; không đổi tên nhân vật cũ thành người chơi mới.

## Điều chỉnh theo phản hồi

- Nét mực và màu nước mềm, ít bóng khối trau chuốt; gương mặt trẻ, dáng thanh.
- Áo vải, đai thắt đơn giản, tay áo thoải mái, giày vải nhẹ; bỏ khóa kim loại lớn, bảo hộ tay và cổ áo đầy họa tiết.
- Tóc buộc thấp, nghiên cứu mặt riêng trong cùng ngôn ngữ nét. Nhận diện khác biệt cuối cùng vẫn cần owner đánh giá; prompt không tự chứng minh đã đạt.
- Ba phối áo xám ấm/xám ngọc/đỏ trầm và bốn góc đầu. Màu áo là nghiên cứu mỹ thuật, không cấp bậc hoặc quyền Đọa Ma.

Đã bổ sung [một mẫu đứng trên map](http://127.0.0.1:5174/van-hai-character-review.html?view=map): góc cao, áo xám ngọc, camera 1×, frame 64 × 96/chân (32,88), cạnh chibi hiện hành. Có zoom/pan, năm vùng xem, đổi nền concept/ảnh tổng quan runtime và frame/điểm chân. Linh Đài tiếp tục dẫn tới review; chưa đổi nhân vật game.

## Mẫu đứng / camera

- [PNG alpha gốc](map-standing-source.png), [WebP](map-standing.webp), [prompt](map-standing.prompt.txt): **built-in image_gen** dùng concept 02 làm nhận diện, sprite cũ chỉ cho camera/chạm đất. PNG được sao chép từ `$CODEX_HOME/generated_images` vào workspace.
- [PNG cỡ chơi](map-standing-study.png): crop alpha/thu thân 33 × 80, đặt vào 64 × 96/neo (32,88). Alpha mềm/nhiều màu; đây là mẫu tỷ lệ, chưa palette pixel/atlas production.
- [Chibi so tỷ lệ](map-baseline.png) sao chép nguyên byte từ [đứng Nam hiện hành](../wang-lin-chibi-walk-v1/native-v2/frames/wanglin_chibi_stand_south.png).
- Builder `build-van-hai-player-map-v2.mjs` chỉ crop/resample/đóng khung, giữ nguồn/alpha; sync kiểm hash. Builder concept giữ scope/approval và mẫu map đã có khi đóng gói lại.
- [Thiết kế/giới hạn](../../../VAN-HAI-CHARACTER-MAP-REVIEW.md), [kiểm map mới](../../../data/van-hai-player-map-v2-verification.json). Cả nền và mẫu cùng zoom; concept 1536 × 1024 đặt ×2 trong world 3072 × 2048; ảnh tổng quan native chưa kiểm layer che người.

## Nguồn và giới hạn

- [PNG gốc](concept-source.png), [WebP](concept.webp), [prompt đầy đủ](concept.prompt.txt), [metadata/hash](assets.json).
- Input: [bảng áo xám/áo đỏ đã duyệt](../wang-lin-initiation-v2.png), được đọc và đưa trực tiếp vào ImageGen làm tham chiếu. [Bản web đối chiếu](reference.webp) chỉ thu mẫu/đổi định dạng, không sửa nguồn cũ.
- Công cụ: skill **imagegen**, **built-in image_gen**. Không CLI, không vẽ raster bằng code.
- `build-van-hai-player-concept-v2.mjs` đóng gói nguồn workspace; sync cũ mở rộng nạp hai phiên bản, có kiểm hash. Roster/profile/save/map/atlas thật không thay.
- [Kiểm kỹ thuật](../../../data/van-hai-player-v2-verification.json): bố cục/lối đối chiếu, nguồn bị phản hồi không còn là mặc định, nạp ảnh, typecheck/build và hồi quy HUD fixture. Kiểm kỹ thuật không duyệt hình.

Mẫu đứng chờ đánh giá tỷ lệ/độ rõ trên nền; chưa pose native hoàn thiện, bốn hướng hoặc walk/cast. Không đổi roster/profile/save/map/navigation hay renderer game. Kiểm concept trước giữ snapshot lịch sử; kiểm map ghi riêng. Sau đối chiếu mới chốt pose native và sản xuất chuyển động; không dùng hình thu nhỏ làm tiêu chuẩn sprite hoàn thiện.
