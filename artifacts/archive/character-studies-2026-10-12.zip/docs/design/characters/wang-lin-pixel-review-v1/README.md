# Vương Lâm nhập môn · mẫu chibi pixel đối chiếu 01

**Phản hồi tiếp nối:** “sau 2 lần sửa tôi thấy không ổn bằng vương lâm hiện hành”. Hai source ở đây giữ lịch sử, `status: rejected-by-owner`, không tiếp tục làm chuẩn hình. [Bản 02](../wang-lin-pixel-review-v2/README.md) lấy trực tiếp concept chibi hiện hành làm gốc. Các kết quả kiểm bên dưới chỉ chứng minh kỹ thuật ở thời điểm review, không là duyệt ART.

**11/10/2026 · hai lần sửa chưa đạt theo owner.** Owner nhận xét chibi hiện hành hợp map hơn nhờ pixel art, và concept mới chưa bám nhân vật Vương Lâm của cốt truyện. Review quay về [nhận diện Vương Lâm v2 đã duyệt](../wang-lin-initiation-v2.png), dùng chibi hiện hành làm gốc tỷ lệ/camera/cụm pixel. Các nghiên cứu nhận diện riêng Vân Hải trước vẫn giữ trong mục chọn, không đổi tên chúng thành Vương Lâm.

[Mở map đối chiếu](http://127.0.0.1:5174/van-hai-character-review.html?view=map): **Vương Lâm · pixel sửa** bên trái, chibi hiện hành bên phải; mặc định camera **1×**, frame **64 × 96**, chân **(32,88)**. Bảng phía trên mặc định là nhận diện Vương Lâm đã duyệt; bản nghiên cứu mặt/tóc riêng trước có nút riêng.

## Bám truyện và giữ ART của game

| Căn cứ | Hệ quả cho tạo hình |
| --- | --- |
| [Chương 1 — Wuxiaworld](https://www.wuxiaworld.com/novel/renegade-immortal/rge-chapter-1), đọc lại 11/10 | Khởi đầu 15 tuổi, ham đọc, gia đình chăm lo đủ ăn mặc: mặt thiếu niên, chú ý/kín đáo, áo thường giản dị nguyên vẹn |
| [Chương 10](https://www.wuxiaworld.com/novel/renegade-immortal/rge-chapter-10), đọc lại 11/10 | Đệ tử ký danh mặc xám; Vương Lâm chịu áp lực, quyết tâm tu luyện, biết giữ kín hạt châu: dùng áo xám, tay trống, không đeo châu lộ ra |
| [Hồ sơ/nhận diện đã duyệt](../../../WANG-LIN-VISUAL-SPEC.md) | Tóc đen dài buộc nửa đầu bằng dây sáng, mặt/vai trẻ, cổ ngà, đai tối và giày vải là ART chuyển thể đã chọn cho game |

Kiểu buộc tóc, đường áo và hình mắt/mũi là lựa chọn ART; các đoạn truyện trên không chốt những chi tiết này. Không đưa tạo hình/thần thái của arc trưởng thành hoặc cảnh giới cao vào mẫu nhập môn. Source không lấy gương mặt hoạt hình hay game khác.

## Source / pixel native

| File | Vai trò |
| --- | --- |
| [standing-source-v2.png](standing-source-v2.png) | Source ImageGen hiện dùng; chỉnh bớt độ dày cụm tóc/nếp áo của source đầu |
| [standing-v2.prompt.txt](standing-v2.prompt.txt) | Prompt chỉnh, input gồm target đầu + sprite hiện hành + bảng Vương Lâm |
| [standing-source.png](standing-source.png), [prompt đầu](standing.prompt.txt) | Source/prompt đầu giữ lịch sử |
| [standing-study.png](standing-study.png) | PNG indexed 64 × 96; một pose đứng Nam, neo (32,88) |
| [standing-study-v1.png](standing-study-v1.png) | Lần xuất đầu, giữ để so độ gọn cụm pixel |
| [standing.webp](standing.webp) | Xem source hiện hành, không dùng thay PNG native |
| [baseline.png](baseline.png) | Chibi hiện hành, sao chép nguyên byte |
| [assets.json](assets.json) | Input/source/crop/hash, palette/alpha, đo chân và trạng thái duyệt |

Công cụ: skill **imagegen**, **built-in image_gen**, alpha thật. PNG được sao chép từ `$CODEX_HOME/generated_images` vào workspace. Export `scripts/build-wang-lin-pixel-review-v1.mjs` lấy mẫu nearest, map vào **palette 24 mục hiện hành**, alpha **0/255**, đóng PNG indexed; không vẽ giải phẫu/pixel thủ công hoặc sinh pose bằng code.

Source v2 1024 × 1536, crop (205,133,600,1354), thu giữ tỷ lệ 35 × 80. Đo trung điểm pixel giày ở năm hàng đáy, không coi tâm ảnh là chân; đặt tại (14,8), hàng tiếp đất y=87 ngay trên neo y=88. Trung điểm chân sau đặt x=32,5 (làm tròn vị trí nguyên pixel). Có đúng 24 màu dùng gồm trong suốt, cùng palette của chibi hiện hành. Palette/alpha đúng kỹ thuật chưa chứng minh nét pixel hoặc mỹ thuật đã đạt.

## Kiểm tra và giới hạn

[Bằng chứng](../../../data/wang-lin-pixel-review-v1-verification.json): sáu viewport/36 bố cục, 858 kiểm đổi mẫu/nền/camera/frame/neo/chạm/kéo/keyboard/expand và bảng nhận diện mặc định. Đã xem sân sáng, vườn tùng và 2×; PNG/source/public hash khớp, baseline không đổi. Typecheck/boundary, Vite build và hồi quy HUD/layer fixture qua; fixture không dùng DB/map/bản nháp owner.

Đây là một mẫu đứng Nam để đánh giá ART, chưa bộ animation/đứng bốn hướng hoặc atlas sản xuất. Không đổi ID/roster/profile/save/avatar runtime hay map/navigation. `ownerApproved: false`, `artApproved: false`; game vẫn dùng bộ hiện hành. Duyệt nhận diện cũ không tự duyệt hình mới. Chốt hình trước khi làm nhiều hướng/động tác và kiểm body/VFX/layer trong game.
